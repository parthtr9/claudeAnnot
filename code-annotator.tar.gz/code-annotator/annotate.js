#!/usr/bin/env node
/**
 * code-annotator/annotate.js
 *
 * Fires after every Write / Edit / MultiEdit tool call.
 * Reads Claude's actual reasoning from the live session transcript (no extra API call),
 * then opens a self-contained HTML annotation window in the default browser.
 */

const fs   = require('fs');
const path = require('path');
const os   = require('os');
const { execSync, spawn } = require('child_process');

// ─── 1. Read hook payload from stdin ────────────────────────────────────────
let raw = '';
try {
  raw = fs.readFileSync('/dev/stdin', 'utf8');
} catch {
  process.exit(0); // nothing on stdin, bail silently
}

let payload;
try {
  payload = JSON.parse(raw);
} catch {
  process.exit(0);
}

const {
  transcript_path,
  tool_name,
  tool_input = {},
} = payload;

// Only care about file-write tools
const WRITE_TOOLS = new Set(['Write', 'Edit', 'MultiEdit']);
if (!WRITE_TOOLS.has(tool_name)) process.exit(0);

// ─── 2. Extract file info from the tool input ────────────────────────────────
function getFileInfo(toolName, input) {
  if (toolName === 'MultiEdit') {
    // MultiEdit has { edits: [{ file_path, old_string, new_string }] }
    const files = [...new Set((input.edits || []).map(e => e.file_path).filter(Boolean))];
    return { filePath: files.join(', '), content: null, isMulti: true, files };
  }
  return {
    filePath: input.file_path || input.path || 'unknown',
    content: input.content || input.new_string || null,
    isMulti: false,
    files: [],
  };
}

const fileInfo = getFileInfo(tool_name, tool_input);

// Read the actual file content from disk (most reliable source)
function readFileContent(fp) {
  try {
    if (fp && fs.existsSync(fp)) return fs.readFileSync(fp, 'utf8');
  } catch {}
  return null;
}

// ─── 3. Parse the transcript JSONL ───────────────────────────────────────────
function parseTranscript(transcriptPath) {
  if (!transcriptPath) return [];
  try {
    const text = fs.readFileSync(transcriptPath.replace(/^~/, os.homedir()), 'utf8');
    return text
      .split('\n')
      .filter(Boolean)
      .map(line => { try { return JSON.parse(line); } catch { return null; } })
      .filter(Boolean);
  } catch {
    return [];
  }
}

const entries = parseTranscript(transcript_path);

// ─── 4. Find Claude's reasoning just before this tool call ───────────────────
// Transcript entries look like:
//   { type: "message", role: "assistant", content: [...blocks] }
//   { type: "tool_use", ... }   ← this is the Write/Edit call we just came from
//
// We want the LAST assistant message before the most recent tool_use for our tool.

function extractAssistantContext(entries, toolName) {
  // Walk backwards through entries
  let foundToolUse = false;
  for (let i = entries.length - 1; i >= 0; i--) {
    const entry = entries[i];

    // Skip until we find the tool_use that matches
    if (!foundToolUse) {
      if (
        (entry.type === 'tool_use' || entry.tool_name === toolName) &&
        (entry.tool_name === toolName || entry.name === toolName)
      ) {
        foundToolUse = true;
      }
      // Also check inside assistant messages for tool_use blocks
      if (entry.role === 'assistant' && Array.isArray(entry.content)) {
        const tu = entry.content.find(
          b => b.type === 'tool_use' && WRITE_TOOLS.has(b.name)
        );
        if (tu) {
          // Extract context from THIS message (thinking + text blocks before the tool_use)
          return extractBlocksFromMessage(entry.content, tu.id);
        }
      }
      continue;
    }

    // Now look for the preceding assistant message
    if (entry.role === 'assistant' && Array.isArray(entry.content)) {
      return extractBlocksFromMessage(entry.content, null);
    }
  }
  return { thinking: [], text: [] };
}

function extractBlocksFromMessage(contentBlocks, stopAtToolUseId) {
  const thinking = [];
  const text = [];

  for (const block of contentBlocks) {
    if (stopAtToolUseId && block.type === 'tool_use' && block.id === stopAtToolUseId) break;

    if (block.type === 'thinking' && block.thinking) {
      thinking.push(block.thinking);
    } else if (block.type === 'text' && block.text) {
      text.push(block.text);
    }
  }
  return { thinking, text };
}

const context = extractAssistantContext(entries, tool_name);

// ─── 5. Build per-line annotations from the content ──────────────────────────
function buildLineAnnotations(fileContent, thinkingBlocks, textBlocks) {
  if (!fileContent) return [];

  const lines = fileContent.split('\n');
  const annotations = [];

  // Simple heuristic: scan thinking/text for line references or code patterns
  // and attach them. For now we produce a structured breakdown by code section.
  const allContext = [...thinkingBlocks, ...textBlocks].join('\n\n');

  // Detect block boundaries (functions, classes, imports, etc.)
  const blockRanges = detectCodeBlocks(lines);

  for (const block of blockRanges) {
    annotations.push({
      startLine: block.start,
      endLine: block.end,
      label: block.label,
      type: block.type,
      // Pull relevant snippet from Claude's reasoning if it mentions this block
      explanation: findRelevantContext(allContext, block.label, lines.slice(block.start - 1, block.end).join('\n')),
    });
  }

  return annotations;
}

function detectCodeBlocks(lines) {
  const blocks = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i].trim();
    const lineNum = i + 1;

    // Import/require blocks
    if (/^(import |from |const .* = require|require\()/.test(line)) {
      let end = i;
      while (end + 1 < lines.length && /^(import |from |const .* = require|require\()/.test(lines[end + 1].trim())) {
        end++;
      }
      if (end > i || line.length > 5) {
        blocks.push({ start: lineNum, end: end + 1, label: 'Imports / dependencies', type: 'import' });
        i = end + 1;
        continue;
      }
    }

    // Class declarations
    if (/^(export\s+)?(abstract\s+)?class\s+\w+/.test(line)) {
      const end = findBlockEnd(lines, i);
      const name = line.match(/class\s+(\w+)/)?.[1] || 'class';
      blocks.push({ start: lineNum, end, label: `Class: ${name}`, type: 'class' });
      i = end;
      continue;
    }

    // Function / method declarations
    if (/^(export\s+)?(async\s+)?function\s+\w+|^\s*(async\s+)?\w+\s*[=:]\s*(async\s+)?\(/.test(line) ||
        /^(export\s+)?(const|let|var)\s+\w+\s*=\s*(async\s+)?(\(|function)/.test(line)) {
      const end = findBlockEnd(lines, i);
      const name = line.match(/function\s+(\w+)/) ||
                   line.match(/const\s+(\w+)/) ||
                   line.match(/(\w+)\s*[:=]/);
      const label = name ? `Function: ${name[1]}` : 'Function block';
      if (end > lineNum) {
        blocks.push({ start: lineNum, end, label, type: 'function' });
        i = end;
        continue;
      }
    }

    // Interface / type declarations (TS)
    if (/^(export\s+)?(interface|type)\s+\w+/.test(line)) {
      const end = findBlockEnd(lines, i);
      const name = line.match(/(interface|type)\s+(\w+)/)?.[2] || 'type';
      blocks.push({ start: lineNum, end, label: `Type: ${name}`, type: 'type' });
      i = end;
      continue;
    }

    i++;
  }

  // If no blocks detected, fall back to grouping every N lines
  if (blocks.length === 0 && lines.length > 0) {
    const chunkSize = Math.min(10, Math.ceil(lines.length / 4));
    for (let start = 1; start <= lines.length; start += chunkSize) {
      blocks.push({
        start,
        end: Math.min(start + chunkSize - 1, lines.length),
        label: `Lines ${start}–${Math.min(start + chunkSize - 1, lines.length)}`,
        type: 'chunk',
      });
    }
  }

  return blocks;
}

function findBlockEnd(lines, startIdx) {
  let depth = 0;
  let started = false;
  for (let i = startIdx; i < lines.length; i++) {
    for (const ch of lines[i]) {
      if (ch === '{') { depth++; started = true; }
      if (ch === '}') depth--;
    }
    if (started && depth === 0) return i + 1;
  }
  return lines.length;
}

function findRelevantContext(fullContext, blockLabel, codeSnippet) {
  if (!fullContext.trim()) return null;

  // Extract a function/variable name from the block label
  const nameMatch = blockLabel.match(/:\s*(\w+)/);
  const name = nameMatch?.[1];

  // Score each sentence in the context by relevance
  const sentences = fullContext.split(/(?<=[.!?])\s+|\n{2,}/);
  const scored = sentences.map(s => {
    let score = 0;
    if (name && s.includes(name)) score += 3;
    if (s.includes(blockLabel)) score += 2;
    // Check if any code token appears
    const codeTokens = codeSnippet.match(/\b\w{3,}\b/g) || [];
    for (const tok of codeTokens.slice(0, 20)) {
      if (s.includes(tok)) score += 0.5;
    }
    return { s, score };
  });

  const best = scored.filter(x => x.score > 0).sort((a, b) => b.score - a.score);
  return best.length > 0 ? best.slice(0, 3).map(x => x.s.trim()).join(' ') : null;
}

// ─── 6. Read file content ────────────────────────────────────────────────────
let primaryContent = null;
let primaryPath = fileInfo.filePath;

if (!fileInfo.isMulti) {
  primaryContent = readFileContent(fileInfo.filePath) || fileInfo.content;
} else {
  // For MultiEdit, show the first affected file
  primaryPath = fileInfo.files[0] || fileInfo.filePath;
  primaryContent = readFileContent(primaryPath);
}

const lineAnnotations = buildLineAnnotations(primaryContent, context.thinking, context.text);

// ─── 7. Render the HTML annotation window ────────────────────────────────────
function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function highlightCode(code, filePath) {
  // Very lightweight syntax highlighting via regex
  const ext = path.extname(filePath).toLowerCase();
  const isTS = ['.ts', '.tsx'].includes(ext);
  const isJS = ['.js', '.jsx', '.mjs'].includes(ext);
  const isPy = ext === '.py';
  const isRust = ext === '.rs';

  let html = escapeHtml(code);

  if (isTS || isJS) {
    // Keywords
    html = html.replace(/\b(const|let|var|function|class|return|if|else|for|while|import|export|from|async|await|new|this|typeof|instanceof|extends|implements|interface|type|enum|namespace|default|switch|case|break|continue|throw|try|catch|finally|void|null|undefined|true|false)\b/g,
      '<span class="kw">$1</span>');
    // Strings
    html = html.replace(/(&#39;[^&#39;]*&#39;|&quot;[^&quot;]*&quot;|`[^`]*`)/g, '<span class="str">$1</span>');
    // Comments
    html = html.replace(/(\/\/[^\n]*)/g, '<span class="cmt">$1</span>');
    html = html.replace(/(\/\*[\s\S]*?\*\/)/g, '<span class="cmt">$1</span>');
    // Numbers
    html = html.replace(/\b(\d+\.?\d*)\b/g, '<span class="num">$1</span>');
    // Function calls
    html = html.replace(/\b(\w+)(\s*\()/g, '<span class="fn">$1</span>$2');
  } else if (isPy) {
    html = html.replace(/\b(def|class|import|from|return|if|elif|else|for|while|in|not|and|or|True|False|None|async|await|with|as|try|except|finally|raise|pass|lambda|yield)\b/g,
      '<span class="kw">$1</span>');
    html = html.replace(/(#[^\n]*)/g, '<span class="cmt">$1</span>');
    html = html.replace(/(&quot;[^&quot;]*&quot;|&#39;[^&#39;]*&#39;)/g, '<span class="str">$1</span>');
    html = html.replace(/\b(\d+\.?\d*)\b/g, '<span class="num">$1</span>');
  }

  return html;
}

function buildAnnotationSidebar(annotations, totalLines) {
  if (!annotations.length) return '<p class="no-ann">No structural blocks detected.</p>';

  return annotations.map((ann, idx) => `
    <div class="ann-block" data-start="${ann.startLine}" data-end="${ann.endLine}" onclick="highlightLines(${ann.startLine}, ${ann.endLine})">
      <div class="ann-header">
        <span class="ann-type ann-type--${ann.type}">${escapeHtml(ann.type)}</span>
        <span class="ann-label">${escapeHtml(ann.label)}</span>
        <span class="ann-lines">L${ann.startLine}–${ann.endLine}</span>
      </div>
      ${ann.explanation
        ? `<div class="ann-body"><p>${escapeHtml(ann.explanation)}</p></div>`
        : `<div class="ann-body ann-body--empty"><p>No specific reasoning extracted for this block.</p></div>`
      }
    </div>
  `).join('');
}

function buildThinkingPanel(thinkingBlocks, textBlocks) {
  const parts = [];

  if (thinkingBlocks.length > 0) {
    parts.push(`<div class="panel-section">
      <h3 class="panel-section-title"><span class="dot dot--think"></span>Extended thinking</h3>
      ${thinkingBlocks.map(t => `<div class="thinking-block"><p>${escapeHtml(t).replace(/\n/g, '<br>')}</p></div>`).join('')}
    </div>`);
  }

  if (textBlocks.length > 0) {
    parts.push(`<div class="panel-section">
      <h3 class="panel-section-title"><span class="dot dot--text"></span>Claude's explanation</h3>
      ${textBlocks.map(t => `<div class="text-block"><p>${escapeHtml(t).replace(/\n/g, '<br>')}</p></div>`).join('')}
    </div>`);
  }

  if (parts.length === 0) {
    parts.push(`<div class="empty-state">
      <p>No reasoning blocks found in the transcript for this write.</p>
      <p class="hint">This can happen when Claude is in a fast iteration loop or extended thinking is not enabled for this session.</p>
    </div>`);
  }

  return parts.join('');
}

const codeLines = primaryContent ? primaryContent.split('\n') : [];
const highlightedCode = primaryContent
  ? highlightCode(primaryContent, primaryPath)
  : '(file content not available)';

const highlightedLines = highlightedCode.split('\n').map((line, i) => {
  const num = i + 1;
  return `<div class="code-line" id="L${num}" data-line="${num}"><span class="ln">${num}</span><span class="lc">${line || ' '}</span></div>`;
}).join('');

const annotationSidebar = buildAnnotationSidebar(lineAnnotations, codeLines.length);
const thinkingPanel = buildThinkingPanel(context.thinking, context.text);

const timestamp = new Date().toLocaleTimeString();
const shortPath = fileInfo.filePath.replace(os.homedir(), '~');
const multiFileBadge = fileInfo.isMulti
  ? `<div class="multi-badge">MultiEdit · ${fileInfo.files.length} files</div>`
  : '';

const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Annotator · ${escapeHtml(path.basename(fileInfo.filePath))}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&family=Syne:wght@400;600;700&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:       #0d0f12;
    --bg2:      #131619;
    --bg3:      #1a1d22;
    --bg4:      #21262d;
    --border:   #2a2f38;
    --border2:  #363d48;
    --text:     #cdd6e0;
    --text2:    #8b95a1;
    --text3:    #5a6370;
    --accent:   #4ade80;
    --accent2:  #22d3ee;
    --think:    #a78bfa;
    --warn:     #fb923c;
    --kw:       #79c0ff;
    --str:      #a5d6a7;
    --cmt:      #4a5568;
    --num:      #ffab70;
    --fn:       #d2a8ff;
    --radius:   6px;
    --header-h: 52px;
    --tabs-h:   40px;
  }

  html, body { height: 100%; background: var(--bg); color: var(--text); font-family: 'Syne', sans-serif; font-size: 14px; }

  /* ── Layout ── */
  .shell { display: grid; grid-template-rows: var(--header-h) 1fr; height: 100vh; overflow: hidden; }
  .main  { display: grid; grid-template-columns: 1fr 340px; overflow: hidden; }
  .left  { display: grid; grid-template-rows: var(--tabs-h) 1fr; overflow: hidden; border-right: 1px solid var(--border); }
  .right { display: grid; grid-template-rows: var(--tabs-h) 1fr; overflow: hidden; }

  /* ── Header ── */
  header {
    display: flex; align-items: center; gap: 12px;
    padding: 0 20px;
    background: var(--bg2);
    border-bottom: 1px solid var(--border);
    position: relative;
  }
  .logo { font-size: 11px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: var(--accent); }
  .sep  { width: 1px; height: 18px; background: var(--border); }
  .filepath { font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--text2); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 480px; }
  .multi-badge { font-size: 10px; background: var(--bg4); border: 1px solid var(--border2); border-radius: 4px; padding: 2px 8px; color: var(--warn); }
  .ts { margin-left: auto; font-size: 11px; color: var(--text3); }
  .pulse { width: 6px; height: 6px; border-radius: 50%; background: var(--accent); animation: pulse 2s ease-in-out infinite; }
  @keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.5;transform:scale(.8)} }

  /* ── Tab bars ── */
  .tabs { display: flex; align-items: center; gap: 2px; padding: 0 12px; background: var(--bg2); border-bottom: 1px solid var(--border); }
  .tab { display: flex; align-items: center; gap: 6px; padding: 0 12px; height: var(--tabs-h); font-size: 12px; font-weight: 600; letter-spacing: 0.04em; color: var(--text3); cursor: pointer; border-bottom: 2px solid transparent; transition: color .15s, border-color .15s; text-transform: uppercase; }
  .tab.active { color: var(--text); border-bottom-color: var(--accent); }
  .tab-count { background: var(--bg4); border-radius: 10px; padding: 1px 6px; font-size: 10px; }

  /* ── Code panel ── */
  .code-scroll { overflow: auto; background: var(--bg); }
  .code-block   { font-family: 'JetBrains Mono', monospace; font-size: 12.5px; line-height: 1.7; padding: 16px 0; min-width: max-content; }
  .code-line    { display: flex; align-items: flex-start; padding: 0 16px; transition: background .1s; }
  .code-line:hover { background: var(--bg3); }
  .code-line.hl { background: rgba(74, 222, 128, 0.07); border-left: 2px solid var(--accent); }
  .code-line.hl-range { background: rgba(74, 222, 128, 0.04); }
  .ln { min-width: 44px; color: var(--text3); user-select: none; font-size: 11px; padding-top: 1px; }
  .lc { white-space: pre; }

  /* Syntax */
  .kw  { color: var(--kw); }
  .str { color: var(--str); }
  .cmt { color: var(--cmt); font-style: italic; }
  .num { color: var(--num); }
  .fn  { color: var(--fn); }

  /* ── Right panel ── */
  .right-scroll { overflow-y: auto; padding: 12px; display: flex; flex-direction: column; gap: 8px; }

  /* Annotation blocks */
  .ann-block {
    background: var(--bg3); border: 1px solid var(--border); border-radius: var(--radius);
    cursor: pointer; transition: border-color .15s, background .15s;
    overflow: hidden;
  }
  .ann-block:hover { border-color: var(--border2); background: var(--bg4); }
  .ann-block.active { border-color: var(--accent); background: rgba(74,222,128,.04); }

  .ann-header { display: flex; align-items: center; gap: 8px; padding: 10px 12px; }
  .ann-label  { font-size: 12px; font-weight: 600; flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .ann-lines  { font-family: 'JetBrains Mono', monospace; font-size: 10px; color: var(--text3); white-space: nowrap; }

  .ann-type {
    font-size: 9px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;
    border-radius: 3px; padding: 2px 5px; flex-shrink: 0;
  }
  .ann-type--import   { background: rgba(122,162,247,.15); color: #7aa2f7; }
  .ann-type--function { background: rgba(210,168,255,.15); color: #d2a8ff; }
  .ann-type--class    { background: rgba(34,211,238,.15);  color: #22d3ee; }
  .ann-type--type     { background: rgba(251,146,60,.15);  color: #fb923c; }
  .ann-type--chunk    { background: rgba(139,149,161,.15); color: #8b95a1; }

  .ann-body { padding: 0 12px 12px; }
  .ann-body p { font-size: 12px; line-height: 1.6; color: var(--text2); }
  .ann-body--empty p { color: var(--text3); font-style: italic; }

  /* Thinking / text blocks */
  .panel-section { margin-bottom: 4px; }
  .panel-section-title {
    display: flex; align-items: center; gap-8px: 8px; padding: 8px 4px 6px;
    font-size: 10px; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text3);
    gap: 8px;
  }
  .dot { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; }
  .dot--think { background: var(--think); }
  .dot--text  { background: var(--accent2); }

  .thinking-block {
    background: rgba(167,139,250,.06); border: 1px solid rgba(167,139,250,.2);
    border-radius: var(--radius); padding: 10px 12px; margin-bottom: 6px;
  }
  .thinking-block p { font-size: 11.5px; line-height: 1.65; color: #c4b5fd; }

  .text-block {
    background: var(--bg3); border: 1px solid var(--border);
    border-radius: var(--radius); padding: 10px 12px; margin-bottom: 6px;
  }
  .text-block p { font-size: 12px; line-height: 1.65; color: var(--text2); }

  .empty-state { padding: 24px 12px; text-align: center; }
  .empty-state p { font-size: 12px; color: var(--text3); margin-bottom: 8px; }
  .hint { font-style: italic; font-size: 11px !important; }

  .no-ann { font-size: 12px; color: var(--text3); padding: 16px; text-align: center; font-style: italic; }

  /* Tab content */
  .tab-content { display: none; }
  .tab-content.active { display: flex; flex-direction: column; overflow: hidden; }
  .fill { flex: 1; overflow: hidden; display: flex; flex-direction: column; }

  /* Scrollbar */
  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 3px; }
  ::-webkit-scrollbar-thumb:hover { background: var(--text3); }

  /* Multi-file list */
  .file-list { padding: 12px; display: flex; flex-direction: column; gap: 4px; }
  .file-item { font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--text2); padding: 6px 10px; background: var(--bg3); border-radius: 4px; border: 1px solid var(--border); }
</style>
</head>
<body>
<div class="shell">

  <!-- Header -->
  <header>
    <div class="pulse"></div>
    <span class="logo">Annotator</span>
    <div class="sep"></div>
    <span class="filepath" title="${escapeHtml(fileInfo.filePath)}">${escapeHtml(shortPath)}</span>
    ${multiFileBadge}
    <span class="ts">${escapeHtml(tool_name)} · ${timestamp}</span>
  </header>

  <!-- Main -->
  <div class="main">

    <!-- Left: code + reasoning tabs -->
    <div class="left">
      <div class="tabs">
        <div class="tab active" onclick="switchLeft('code', this)">Code</div>
        <div class="tab" onclick="switchLeft('reasoning', this)">
          Reasoning
          <span class="tab-count">${context.thinking.length + context.text.length}</span>
        </div>
        ${fileInfo.isMulti ? `<div class="tab" onclick="switchLeft('files', this)">Files <span class="tab-count">${fileInfo.files.length}</span></div>` : ''}
      </div>

      <!-- Code view -->
      <div id="left-code" class="tab-content active fill">
        <div class="code-scroll fill">
          <div class="code-block" id="code-block">
${highlightedLines}
          </div>
        </div>
      </div>

      <!-- Reasoning view -->
      <div id="left-reasoning" class="tab-content fill">
        <div class="right-scroll fill">
          ${thinkingPanel}
        </div>
      </div>

      ${fileInfo.isMulti ? `
      <!-- Files view -->
      <div id="left-files" class="tab-content fill">
        <div class="file-list">
          ${fileInfo.files.map(f => `<div class="file-item">${escapeHtml(f.replace(os.homedir(), '~'))}</div>`).join('')}
        </div>
      </div>` : ''}
    </div>

    <!-- Right: annotations -->
    <div class="right">
      <div class="tabs">
        <div class="tab active">Annotations <span class="tab-count">${lineAnnotations.length}</span></div>
      </div>
      <div class="right-scroll">
        ${annotationSidebar}
      </div>
    </div>

  </div>
</div>

<script>
  function switchLeft(tab, el) {
    document.querySelectorAll('.left .tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.left .tab-content').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('left-' + tab)?.classList.add('active');
  }

  function highlightLines(start, end) {
    // Clear previous highlights
    document.querySelectorAll('.code-line').forEach(l => {
      l.classList.remove('hl', 'hl-range');
    });

    // Highlight new range
    for (let i = start; i <= end; i++) {
      const el = document.getElementById('L' + i);
      if (el) {
        el.classList.add(i === start ? 'hl' : 'hl-range');
      }
    }

    // Update active annotation block
    document.querySelectorAll('.ann-block').forEach(b => b.classList.remove('active'));
    event.currentTarget.classList.add('active');

    // Scroll code into view — switch to code tab first
    switchLeft('code', document.querySelector('.left .tab'));
    setTimeout(() => {
      const target = document.getElementById('L' + start);
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 50);
  }

  // Auto-highlight first annotation on load
  window.addEventListener('load', () => {
    const first = document.querySelector('.ann-block');
    if (first) {
      const start = parseInt(first.dataset.start);
      const end   = parseInt(first.dataset.end);
      for (let i = start; i <= end; i++) {
        const el = document.getElementById('L' + i);
        if (el) el.classList.add(i === start ? 'hl' : 'hl-range');
      }
      first.classList.add('active');
    }
  });
</script>
</body>
</html>`;

// ─── 8. Write HTML and open browser ──────────────────────────────────────────
const tmpFile = path.join(os.tmpdir(), `annotator-${Date.now()}.html`);
fs.writeFileSync(tmpFile, html, 'utf8');

// Platform-specific open
const platform = os.platform();
try {
  if (platform === 'darwin') {
    spawn('open', [tmpFile], { detached: true, stdio: 'ignore' }).unref();
  } else if (platform === 'win32') {
    spawn('cmd', ['/c', 'start', '', tmpFile], { detached: true, stdio: 'ignore' }).unref();
  } else {
    // Linux — try several openers
    const openers = ['xdg-open', 'sensible-browser', 'firefox', 'chromium-browser', 'google-chrome'];
    let opened = false;
    for (const opener of openers) {
      try {
        execSync(`which ${opener}`, { stdio: 'ignore' });
        spawn(opener, [tmpFile], { detached: true, stdio: 'ignore' }).unref();
        opened = true;
        break;
      } catch {}
    }
    if (!opened) {
      // Last resort: write path to stderr so user knows where the file is
      process.stderr.write(`[annotator] Open manually: ${tmpFile}\n`);
    }
  }
} catch (e) {
  process.stderr.write(`[annotator] Failed to open browser: ${e.message}\n`);
}

process.exit(0);
